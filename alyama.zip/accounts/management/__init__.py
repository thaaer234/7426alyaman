"""Management package for accounts app."""

